from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName("LinkCount")
sc = SparkContext.getOrCreate(conf=conf)

n = 50  # so luong trang Web top duoc lien ket den nhieu nhat

# duong dan toi file can doc
file_path = "/home/dinhvu/Downloads/bt3/data.txt"

# doc file va dem so luong lien ket den tung trang Web
counts = (
    sc.textFile(file_path)
    .map(lambda line: line.strip().split('\t'))
    .map(lambda x: (x[1], 1))
    .reduceByKey(lambda x, y: x + y)
)

# lay top n trang Web duoc lien ket den nhieu nhat
top_nodes = (
    counts
    .map(lambda x: (x[1], x[0]))  # doi vi tri key va value de co the sap xep
    .sortByKey(ascending=False)
    .take(n)
)

# in ra top n trang Web duoc lien ket den nhieu nhat
for (count, node) in top_nodes:
    print(f"{node}\t{count}")


