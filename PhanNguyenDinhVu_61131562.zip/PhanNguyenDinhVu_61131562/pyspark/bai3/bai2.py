from pyspark import SparkContext

sc = SparkContext(appName="LinkList")

# doc file tu may tinh
lines = sc.textFile("/home/dinhvu/Downloads/bt3/data.txt")

# Tao RDD gom cac cap key-value
# Trong do key la ten trang web, value la ten cac trang web ma trang do lien ket den
links = lines.map(lambda line: line.strip().split('\t')) \
             .map(lambda x: (x[0], x[1]))

# GroupByKey de tao danh sach cac trang web lien ket voi moi trang web
linked_nodes = links.groupByKey() \
                    .mapValues(list)

# In ra ket qua
for (node, links) in linked_nodes.collect():
    print(f"{node}\t{links}")
