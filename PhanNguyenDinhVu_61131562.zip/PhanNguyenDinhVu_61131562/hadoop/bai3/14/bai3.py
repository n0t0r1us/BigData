import networkx as nx
import matplotlib.pyplot as plt

# doc du lieu tu file
with open("data.txt", "r") as f:
    data = f.readlines()

# Tao do thi
G = nx.DiGraph()

# Them canh tu fromNodeId den toNodeId voi trong so weight
for line in data:
    line = line.strip().split("\t")
    fromNodeId = int(line[0])
    toNodeId = int(line[1])
    G.add_edge(fromNodeId, toNodeId)

# Ve do thi
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G, pos, node_size=10)
nx.draw_networkx_edges(G, pos, alpha=0.5)
plt.axis('off')
plt.show()
